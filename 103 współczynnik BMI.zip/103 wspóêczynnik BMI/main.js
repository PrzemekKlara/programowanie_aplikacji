
const wynik = document.querySelector('#wynik');
const btn = document.querySelector('button');
btn.addEventListener('click', function() {
    let height = parseInt(document.querySelector("#height").value)/100;
    let weight = parseInt(document.querySelector("#weight").value);
    let a = weight/(height*height);

    switch (true) {
        case a<16:
            return wynik.innerHTML = 'Wygłodzenie ';
            break;
        case  a >= 16 && a<17:
            return wynik.innerHTML = 'Wychudzenie ';
            break;
        case  a >= 17 && a<18,5:
            return wynik.innerHTML = 'Niedowaga ';
            break
        case  a >= 18,5 && a<25:
            return wynik.innerHTML = 'Optimum ';
            break;
        case  a >= 25 && a<30:
            return wynik.innerHTML = 'Nadwaga ';
            break;
        case  a >= 30  && a<35:
            return wynik.innerHTML = 'Otyłość I st. ';
            break;
        case  a >= 35 && a<40:
            return wynik.innerHTML = 'Otyłość II st.';
            break;
        case  a >=40:
            return wynik.innerHTML = 'Otyłość III st.';
            break;
        default:
            wynik.innerHTML = 'error ';

    }})